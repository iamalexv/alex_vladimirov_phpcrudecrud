# alex_vladimirov_phpcrudecrud
PHP Crude Crud web app deployment for employee database using apache, linux, php, and mariadb
